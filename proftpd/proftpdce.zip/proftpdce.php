<?PHP
  $cfn = "/etc/proftpd.conf";
  $tfn = "/tmp/proftpd.conf";
  $eline = 0;
  $ecount = 0;

  // Create temporary config file
  exec ("cp $cfn $tfn");

  if (isset($_POST['content']))
  {
    // Prepare config file content for writing
    $content = stripslashes($_POST['content']);
    $content = preg_replace('/(\r\n|\r|\n)/s',"\n",$content);
    $content = trim ($content);

    // Save content to temporary config file
    $fp = fopen($tfn,"w") or die ("Error opening file in write mode!");
    fputs($fp,"$content\n");
    fclose($fp) or die ("Error closing file!");

    // Check config for errors
    $output = array();
    exec ("/usr/local/sbin/proftpd -t -c $tfn 2>&1", $output, $ret_value);
    if (count($output) == 1 && $ret_value == 0)
    {
      // No errors found. Save config file.
      $fp = fopen($cfn,"w") or die ("Error opening file in write mode!");
      fputs($fp,"$content");
      fclose($fp) or die ("Error closing file!");
      $smessage = "Config file successfully saved. Please restart ProFTPD to activate them!";
    }
    else
    {
      // Warning or error was found, remove first obsolete message
      array_splice($output, 0, 1);
      foreach ($output as &$line)
      {
        // Remove unnecessary info from messages
        $line = str_replace(" of '/tmp/proftpd.conf'", "", $line);
        $line = str_replace(" '/tmp/proftpd.conf'", "", $line);
        if (strpos ($line, ": ") > 0)
          $line = substr ($line, strpos ($line, ": ") + 2);
        // Extract line number if given in warning or error message
        $pos = strpos ($line, " line ");
        if ($pos > 0)
          // Extract only the first one (textarea can only select one)
          if ($ecount < 2)
          {
            $eline = substr ($line, $pos + 6);
            $ecount++;
          }
        $line = htmlspecialchars ($line);
      }
      unset ($line);
      $output[] = "Config will not be saved. Please correct the problem(s)!";
      $soutput = implode ("\n", $output);
    }
  }
?>
<html>
  <head>
  </head>
  <body>
    <script src="jquery-1.8.3.min.js"></script>
    <script src="jquery-linedtextarea.js"></script>
    <link href="jquery-linedtextarea.css" type="text/css" rel="stylesheet" />
    <form name="proftpd_config" method="POST" action="proftpdce.php">
      <div style="position:relative; width:100%">
        <textarea id="confedit" class="lined" style="width:100%" rows="15"
          cols="80" name="content"><?php
          $out=$file = file_get_contents("$tfn");
          $out=trim($out);
          echo $out;
        ?></textarea>
        <div style="float: right; font-size:80%">
          Powered by <a href="http://jquery.com/" target="_blank">jQuery</a> and
          <a href="http://alan.blog-city.com/jquerylinedtextarea.htm"
            target="_blank">jQuery Lined TextArea Plugin</a>
        </div>
        <input type="submit" name="submit" style="margin-top:5px;" value="Check&Save">
      </div>
    </form>
    <?php echo "<pre>$soutput</pre>"; ?>
    <div id="response">
        <?php echo "<pre>$smessage</pre>"; ?>
    </div>
    <br />
    <script>
      $(function(){
        if (!$.browser.msie) {
          $(".lined").linedtextarea(<?php
            if ($eline > 0) echo "{selectedLine: $eline}";
          ?>);
        }
      });
      $('#confedit').bind('input propertychange', function(){
        if (this.value.length){
           $('#response').empty();
        }
      });
    </script>
  </body>
</html>